/**
 * @file: Fortune teller.js
 * @author: Bioletto Marco
 * A demonstration of Variables
 *
 * I decided to use three const type functions to know how many children you want to have, with whom you will have these children and finally what job you would like to do
 * I decided to use country as a let variable to know where I live
 *  Finally the service requires printing
 */
const numfigli=prompt("Quanti figli vorresti avere! :");
//let numfigli=5;
console.log("Il numero di figli che ho con mia moglie è : %d",numfigli);
const paese=prompt("Dove vorresti vivere con la ragazza !")
//let paese='Torino';
console.log("Io con mia moglie e i miei figli abito a: %s",paese);
const moglie=prompt("Con quale ragazza sei fidanzato o sposato! :")
//let moglie= 'Federica';
console.log("Mi sono sposato 4 anni fa con mia moglie : %s",moglie);
const job_title=prompt("Quale lavoro voresti fare! :")

//let job_title= 'Programmatore';
console.log("You will be a "+job_title+" in "+paese+" , and married  to "+moglie+" with "+numfigli+" kids")