
/**
 * @file: Geometry.js
 * @author: Bioletto Marco
 * A demonstration of Variables
 * 
 * I decided to use the const variable to add any radius that you want
 * I decided to use the variable let circumference with the function Math.PI(pi)
 * I decided to use the let area variable with the radius*radius*Math.PI function
 * Finally, the exercise requires printing
 */

const raggio=prompt("Quale il raggio del cerchio! : ")
//let raggio=10;
console.log("Il raggio è : %d cm",raggio);
let circonferenza = raggio*Math.PI;
let area=raggio*raggio*Math.PI;
console.log("The circumference is "+circonferenza+". The area is "+area);
