
/**
 * @file: Coffee supply.js
 * @author: Bioletto Marco
 * A demonstration of Variables
 * 
 * I decided to use the const function to make each user add their supply of coffee they drink per day
 * I decided to use the const function to make each user add their supply of coffee they drink per day
 * I've decided to use the let coffee variable to store how many coffees I drink per day
 * I decided to use coffee quantity as the let variable to calculate how many coffees I drink in a single year
 * I decided to use as variable let Calculate to calculate how many coffees it takes from today until the end of life
 * Finally, the exercise requires printing
 */

const età=prompt("Inserisci la tua età ! : ");
//let età=20;
console.log("La mia età attuale è : %d anni",età);
let etàmassima=99;
console.log("L'età massima che ho deciso è : %d anni", etàmassima);
let caffè=4;
console.log("I caffè che bevo al giorno sono: %d",caffè);
let quantitàcaffè=caffè*365;
console.log("La quantità di caffè che bevo al giorno è : %d ",quantitàcaffè);
let Calcola=etàmassima-età;
let caffètotali=quantitàcaffè*Calcola;
console.log("La quantità di caffe che berrò da oggi fino alla fine della mia vità è: %d ", caffètotali)