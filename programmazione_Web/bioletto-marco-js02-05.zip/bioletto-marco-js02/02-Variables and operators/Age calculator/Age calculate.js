/**
 * @file: Age calculator.js
 * @author: Bioletto Marco
 * A demonstration of Variables
 * 
 * This exercise calculates current age and an assumed future date
 * I decided to use the cost function to have each user enter their date of birth
 * I decided to use the let future date variable to store a random future date
 * I decided to use the let difference variable to calculate the difference between the future date and the birth date
 * Finally, the exercise required printing
 */

const datanascita=prompt("In che anno sei nato! : ");
//let datanascita= 2002;
console.log("La mia data di nascita è : %d",datanascita);
let datafutura=2030;
console.log("Una data futura a caso %d :", datafutura);
let differenza= datafutura-datanascita;
console.log( "I will be either "+ differenza +" or "+ (differenza -1) + " in " + datafutura);
function INVIA(){
    
    let name = Number(document.getElementById("name").value);
    let surname = Number(document.getElementById("surname").value);
    let Date_of_birth = Number(document.getElementById("Date of birth").value);
    let Text_of_code= Number(document.getElementById("Text of code").value);
    }