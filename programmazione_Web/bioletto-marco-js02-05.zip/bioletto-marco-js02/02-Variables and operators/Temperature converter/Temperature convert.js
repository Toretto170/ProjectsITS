/**
 * @file: Temperature convert.js
 * @author:Bioletto Marco
 * A demonstration of Variables
 * 
 *  I decided to use the const function to allow each user to put the temperature to convert in degrees Fahrenheit
 *  I decided to use as let variable Fahrenheit to convert Celsius to Fahrenheit using a function
 * Finally, the exercise has two prints
 * 
 */
const Celsius=prompt("Scegli temperatura : ")
//let Celsius=25;
console.log("La temperatura misurata in Celsius è : %d°C",Celsius);
let Fahrenheit=(Celsius*9/5)+32;
console.log("La temperatura misurata in Fahrenheit è : %d°F",Fahrenheit)
console.log(""+Celsius+"°C is"+Fahrenheit+"°F")
console.log(""+Fahrenheit+"°F is "+Celsius+"°C");