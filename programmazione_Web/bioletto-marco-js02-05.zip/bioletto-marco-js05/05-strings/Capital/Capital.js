/**
 * @file: capital.js
 * @author: Bioletto Marco
 * Exercise on Strings in Javascript
 * 
 * Write a JavaScript function called capital which has one parameter of type a string,
 * and which returns that string with the first letter capitalized.
 * modify the function so that it capitalizes each word.
*/
 function capital(stringa) {
    let maiuscola = stringa.charAt(0).toUpperCase() + stringa.slice(1);

    return maiuscola;
}
let string = "la juventus ha vinto 38 scudetti(9 di fila)";

console.log(capital(string)); 

 


