/**
 * @file:fix-start.js
 * @author: Bioletto Marco
 * Exercise on Strings in Javascript
 * 
 * 
 */

/**
 * function that substitute with * from the second instance of first character
 */
function fixStart(stringa) {
    if (typeof stringa !== "string") {
        console.error("Errore ");
    }
    let strRisult= stringa.slice(1);
    let fC = stringa.charAt(0);
    const re = new RegExp(fC,"gi");
    strRisult= strRisult.replace(re,"*");
    return (fC+strRisult);
}

console.log(fixStart("Mondo"));
console.log(fixStart(18)); 