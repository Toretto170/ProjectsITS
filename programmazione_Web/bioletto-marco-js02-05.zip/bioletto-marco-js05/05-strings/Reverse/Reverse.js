/**
 * @file: reverse.js
 * @author: Bioletto Marco
 * Exercise on Strings in Javascript
 * 
 * Write a JavaScript function called printReverse which has one parameter of type a 
 * string, and which prints that string in reverse.
 */
 function printReverse(stringa) {
    let Risultato=" ";
    for(i=stringa.length;i>=0;i--){
        
        Risultato=Risultato+stringa.charAt(i); 
    }
    console.log(Risultato);
}
let stringa = "Juventus";
console.log(stringa);
printReverse(stringa);
