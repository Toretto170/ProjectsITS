/**
 * @file: not-bad.js
 * @author: Bioletto Marco
 * Exercise on Strings in Javascript
 * 
 * Create a function named notBad and pass it a string
 * If the string finds it, it is not placed in front of it, otherwise it is not
 *If the string finds it, it is not placed in front of it, otherwise it is not
 */

 function notBad(str) {
    
}