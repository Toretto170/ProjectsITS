/**
 * @file: reverse2.js
 * @author: Bioletto Marco
 * Exercise on Strings in Javascript
 * 
 * Write a JavaScript function called reverse which has one parameter, a string,
 * and which returns that string in reverse.
 * function that take a string and return the same string but in reverse order
 */
 function printReverse(stringa) {
    let esito=" ";
    for(i=stringa.length;i>=0;i--){
        
        esito=esito+stringa.charAt(i); 
    }
    console.log(esito);
}
let stringa = "JuventusU20";
console.log(stringa);
printReverse(stringa);