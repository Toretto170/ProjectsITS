/**
 * @file: the-group.js
 * @author: Bioletto Marco
 *A demonstration of String
 /*This exercise asked to call the function called group 
 The function should output the results to the console.
 */
function groupName(nome, gruppoLista) {
    let stringa3= gruppoLista.includes(mome);
    if (stringa3) {
    console.log({nome});
    } else {
    console.log({nome});
    }
    }
    let gruppi = "Marco, Giulia and Ludo";
    let Nomevecchio = "Marco";
    groupName(Nomevecchio, gruppi);
    
    let Nomenuovoragazzo = "Lorenzo";
    groupName(Nuovogruppo, gruppi);
    
    