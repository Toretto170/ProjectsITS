/**
 * @file: contains.js
 * @author: Bioletto Marco
 * Exercise on Strings in Javascript
 * 
 *  This exercise asked to call the aContainsb function with two strings in it
 * Should return true if it's the first string contains the second otherwise return false
 */
function aContainsB(str1, str2) {
return str1.includes(str2);
}
console.log(aContainsB("Un'altro Ciao Mondo", "Mondo "))
console.log(aContainsB("Buonanotte", "Sole")); 

