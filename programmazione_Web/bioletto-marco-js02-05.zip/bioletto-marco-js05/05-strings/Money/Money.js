/**
 * @file: money.js
 * @author:Bioletto Marco
 * Exercise on Strings in Javascript
 * 
 * This exercise asks you to make a Money function and pass it the amount and return
 * add case checking that is not a number or a valid number
 * Convert the value to dollars
 */
function money(importo) {
    if (typeof importo === Number) {
        
        console.error('incorrect data type');
    }
    if(importo<1000000000){
        return importo +" Dollari";
    }
     
    return importo +"dollari con lo smiley :)";
        
    
    }

console.log(money(10));
console.log(money(1000000));
