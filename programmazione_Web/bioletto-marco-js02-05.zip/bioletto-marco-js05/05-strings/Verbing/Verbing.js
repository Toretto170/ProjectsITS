/**
 * @file: verbing.js
 * @author: Bioletto Marco
 * Exercise on Strings in Javascript
 * 
 * This exercise asks you to call the verb function and pass it a verb
 * If the length of the string is greater than 3, a verb in "ing" must be returned, otherwise the string must be left unchanged
 *keep in mind some English grammar, ie if it ends in a consonant you double it
*/
function verbing(stringa) {
    let stringainvariata=stringa.slice(-3);
    if (stringa.length>3 && stringainvariata!="ing") {
        return stringa +"ing";
    } else 
        if(stringa.length>3&& stringainvariata=="ing") {
        return stringa+"ly";
    } 
    return stringa;
}
console.log(verbing("Travel")); 
console.log(verbing("Travelling")); 
console.log(verbing("go")); 
