

/**
 * @file: mix-up.js
 * @author: Bioletto Marco
 * Exercise on Strings in Javascript
 * 
 * This exercise asks you to make a function called mixUp and return the concatenation of the entered strings
 * function that swaps the first two character of two string
*/
 function mixUp(stringa1,stringa2) {
    let a=stringa2.slice(0,2);
    let b=stringa1.slice(0,2);
    stringa1 = a + stringa1.slice(2);
    stringa2 = b + stringa2.slice(2);
    return stringa1+" " +stringa2;
}
console.log("Forza Juventus");
console.log(mixUp("Forza","Juventus"));
console.log("mix pod");
console.log(mixUp("mix","pod"));