/**
* @file: multiplication-tables.js
* @author: Bioletto Marco
* Exercise on the flow of javascript
*
*  Uses a for loop to multiply a numer by 9 
*Using a nested loop to print all multiplication tables from 1 to 10
 */
for (let i = 0; i <= 10; i++) {
    let risulato = i*9;
    console.log(i+"*9= "+risulato);
}
for (let i= 1; i<=10; i++) {
    for(i2=0;i2<10;i2++){
        let risulato = i2 * i;
        console.log(i2+'*'+i+'='+risulato);
    }  
}

