/**
 * @file: the even/odd reporter.js
 * @author: Bioletto Marco
 *A demonstration of flow
 *
 * I called the Numberevenodd function
 * I decided on a variable(s) to make the for loop
 * Then I put a for loop that says until it reaches the end of the condition continue to go on
 *If the number divisible by 2 prints out that the number is even, otherwise if a number not divisible by 2 comes out it means that it is an odd number
 */

 function Numberevenodd(numeroparidispari){
    let i=" ";
    for(i=0;i<20;i++){
        if(i%2==0){
            console.log(i+"is even");
        }
        else 
        console.log(i+"is odd");
    }
}