/**
 * @file: the-world-traslator.js
 * @author: Bioletto Marco
 *A demonstration of flow
 *
 * I called the function helloWorld
 * I used the switch to define different languages ​​including (English, Italian, French, German, Japanese and finally Albanian)
 * Finally I called the function with helloWorld 7 times with the default that will return the English language 
  */




 function helloWorld(codicelingue) {
    switch (codicelingue) {
        case "en":
            console.log("Hello World");
            break;
        case "it":
            console.log("Ciao Mondo");
            break;
        case "fr":
            console.log("Bonjour tout le monde");
            break;
        case "de":
            console.log("Hallo Welt");
            break;
        case "jp":
            console.log("こんにちは世界");
            break;
        case "ab":
            console.log("Pershendetje bote");
            break;
        default:
            console.log("Hello World");
            break;
    }
}
helloWorld("en");
helloWorld("it");
helloWorld("fr");
helloWorld("de");
helloWorld("jp");
helloWorld("ab");
helloWorld("default");
