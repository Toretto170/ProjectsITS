/**
 * @file: bigger-number.js
 * @author: Bioletto Marco
 *A demonstration of flow
 *
 * As a first step I called the GreaterNum function
 * In the next step I did 2 if, I said if the first number is greater than the second return the first otherwise return the second number
 * Finally I called the same function three more times with different values
 */


function greaterNum(num1,num2){
    if(num1>num2){
        return num1;
    }
    else{
        return num2; 
    }
}
let num1 =10;
let num2=20;
console.log("The greater number between "+num1+" and " +num2+ " is "+ greaterNum(num1,num2))
let num3 =30;
let num4=45;
console.log("The greater number between "+num3+" and " +num4+ " is "+ greaterNum(num3,num4))
let num5 =80;
let num6=25;
console.log("The greater number between "+num5+" and " +num6+ " is "+ greaterNum(num5,num6))
let num7 =50;
let num8=19;
console.log("The greater number between "+num7+" and " +num8+ " is "+ greaterNum(num7,num8))


