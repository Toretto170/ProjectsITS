/**
* @file: the-pluralizer.js
* @author: Bioletto Marco
* Exercise on the flow of javascript
*
* I called the pluralize function which returns the respective noun in the plural (adding the s)
* Finally I called the function again to show that if I put a noun and a number <1 it returns the same noun in the singular
 */






function pluralize(sostantivo, numero) {  
    if (numero > 1) {
        sostantivo+='s';
    } 
    return sostantivo; 
}

let sostantivo ='dog';
let numero = 2;
console.log(numero +  " " + pluralize(sostantivo,numero));
noun ='rabbit';
number = 1;
console.log(numero + " " + pluralize(sostantivo,numero));