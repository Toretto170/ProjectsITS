/**
* @file: the-grade-assigner1.js
* @author: Bioletto Marco
* Exercise on the flow of javascript
*
* Uses the function assignGrad to trasform a numeric score in a letter grade 
* 
* function that transform a number score in a grade score, uses the variables lS that stand for letter score
* A 0-59
* B 60-69
* C 70-79
 *D 80-89
 *E 90-100
 */
function assignGrade(punteggionumerico) {
    let lS = "";
    if (punteggionumerico>=0 && punteggionumerico<=59) {
        return punteggionumerico="A";
    } else if (punteggionumerico>=60 && punteggionumerico<=69) {
        return punteggionumerico="B";
    } else if(punteggionumerico>=70 && punteggionumerico<=79){
        return punteggionumerico='C';
    } else if (punteggionumerico>=80 && punteggionumerico<=89) {
        return punteggionumerico='D';
    }else if (punteggionumerico>=90 && punteggionumerico<=100) {
        return punteggionumerico='F';
    } else{
        return "Errore";
    }
 }
let vote =assignGrade(2);
console.log(vote);
vote =assignGrade(8);
console.log(vote);
vote =assignGrade(15);
console.log(vote);
vote =assignGrade(22);
console.log(vote);
vote =assignGrade(27);
console.log(vote);
//Controllo errori
vote =assignGrade(-5); 
console.log(vote);
vote =assignGrade(36);
console.log(vote);

    