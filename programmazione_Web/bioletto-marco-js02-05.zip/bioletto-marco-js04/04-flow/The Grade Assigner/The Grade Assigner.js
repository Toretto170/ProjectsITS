/**
* @file: the-grade-assigner.js
* @author: Bioletto Marco
* Exercise on the flow of javascript
*
* Uses the function assignGrad to trasform a numeric score in a letter grade 
* 
* function that transform a number score in a grade score, uses the variables lS that stand for letter score
* A 0-10
*B 12-21
* C 24-32
 * D 35-43
 * E 45-54
 * F 55-100
 */
 function assignGrade(punteggionumerico) {
    let lS = "";
    if (punteggionumerico>=0 && punteggionumerico<=10) {
        return punteggionumerico="A";
    } else if (punteggionumerico>=11 && punteggionumerico<=22) {
        return punteggionumerico="B";
    } else if(punteggionumerico>=23 && punteggionumerico<=33){
        return punteggionumerico='C';
    } else if (punteggionumerico>=34 && punteggionumerico<=44) {
        return punteggionumerico='D';
    }else if (punteggionumerico>=44 && punteggionumerico<=55) {
        return punteggionumerico='F';
    } else{
        return "Errore";
    }
 }
let vote =assignGrade(2);
console.log(vote);
vote =assignGrade(8);
console.log(vote);
vote =assignGrade(15);
console.log(vote);
vote =assignGrade(22);
console.log(vote);
vote =assignGrade(27);
console.log(vote);
//Controllo errori
vote =assignGrade(-5); 
console.log(vote);
vote =assignGrade(36);
console.log(vote);

    