/**
 * @file: Math library.js
 * @author:Bioletto Marco
 * function that give the square of a given number
 * function that give the half of a given number
 */
 function squareNumber(numero) {
    let numerocerchio = Math.pow(numero,2);
    console.log("The result of squaring the number"+numero+" is" +numerocerchio);
    return numerocerchio;
}
squareNumber(10);

function halfNumber(numero) {
    let divisione = numero/2;
    console.log('Half of '+numero+' is '+divisione);
    return divisione;
}
halfNumber(20);






