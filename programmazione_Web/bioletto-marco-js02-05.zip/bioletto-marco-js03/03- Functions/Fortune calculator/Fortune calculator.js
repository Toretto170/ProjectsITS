/**
 * @file: fortune-calculator.js
 * @author: Bioletto Marco
 * A demonstration of Functions
 * 
 * the exercise involves calling a function called tellForture and passing four arguments with print
 * Finally the exercise asked to call the tellFortune function 3 more times and pass it different values  
 */
function tellFortune(numfugli,moglie,paese,job_title){
    console.log("You will be a "+job_title+" in "+paese+", and married to "+moglie+" with "+numfugli+" kids");
}
tellFortune(10,'Federica','Torino','Programmatore');
tellFortune(5,'Ludovica','Milano','Eletrauto');
tellFortune(2,'Luisa','Roma','Assistente laboratorio');
tellFortune(1,'Giorgia','New York','Idraulico');