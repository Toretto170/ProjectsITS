/**
 * @file: Geometry library.js
 * @author: Bioletto Marco
 * A demonstration of functions
 * Exercise asks to calculate the circumference of a circle
 * Exercise asks to calculate the circumference of a circle
 * Then it asks to call the function 3 more times and pass it different values
 */




function calcCircumfrence(raggiocerchipercirconferenza){
    let Circonferenza = raggiocerchipercirconferenza*Math.PI
    console.log("The circumference is "+Circonferenza);
}
calcCircumfrence(10);
calcCircumfrence(20);
calcCircumfrence(30);
calcCircumfrence(40);
function calcArea(raggiocerchioperarea){
    let area = raggiocerchioperarea*raggiocerchioperarea*Math.PI
    console.log("The area is "+area);
}
calcArea(10);
calcArea(20);
calcArea(30);
calcArea(40);