/**
 * @file: variable-scope.js
 * @author: Bioletto Marco
 * A demonstration of functions
 * 
 * This exercise recreates local and global variables
 * The second step was to call the addNumbers function other times and enter some values at will
 */
// A variable with "local" scope:
function addNumbers(num1, num2) {
let localResult = num1 + num2;
 console.log("The local result is: " + localResult);
}
addNumbers(15,17);
addNumbers(60,67);
addNumbers(75,75);
addNumbers(80,80);




//A variable with "global" scope:
let globalResult;
function addNumbers1(num1, num2) {
 globalResult = num1 + num2;
 console.log("The global result is: " + globalResult);
}
addNumbers1(10,10);
addNumbers1(20,20);
addNumbers1(30,30);
addNumbers1(40,40);






