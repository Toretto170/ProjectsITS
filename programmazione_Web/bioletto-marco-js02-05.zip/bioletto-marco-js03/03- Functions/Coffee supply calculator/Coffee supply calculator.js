/**
 * @file: coffee suplly calculator.js
 * @author: Bioletto Marco
 *A demonstration of functions
 *function that calculates the number of cups of coffee needed for the rest of life
*/
function calcolaSupply ( età ,  quantitàcaffè)  {
    let etàattuale =30;
    let caffè =4;
    let etàmassima  =  99;
    let calcola =  etàmassima - età ;
    let caffètotali=caffè*calcola;
   console.log ("You'll need "+ caffètotali+" cups of coffee that last to a ripe old age " + etàmassima) ;
}
calcolaSupply(20,4);
