/**
 * @file: Math library1.js
 * @author:Bioletto Marco
 * function that give the square of a given number
 * * function that give the half of a given number
 */


function percentOf(num1,num2) {
    let numPercentuale= (num1/num2)*100
    console.log(num1+' is '+numPercentuale+'% of '+num2);
    return numPercentuale; 
}
function areaOfCircle(raggioCerchio) {
    let area = Math.PI * (Math.pow(raggioCerchio,2));
    console.log("The area for a circle with radius "+ raggioCerchio+" is "+ area.toFixed(2));
    return area;
}
percentOf(3,4);
areaOfCircle(2);