/**
 * @file: dog-age-calculator.js
 * @author: Bioletto Marco
 * A demonstration of functions
 *  This exercise asked to calculate the age of a dog in the respective human age
 * Exercise required calling the age calculator function three more times with different values
 * The second part of the exercise required you to do exactly the opposite (i.e. calculate human age and say how old the dog is).
 */
function calcolaDogAge(etàcaneumana){
    let etàumana=etàcaneumana*7
    console.log("Your dog is "+etàumana+" years old in dog years  and "+etàcaneumana+" in uman years!");
}
calcolaDogAge(2);
calcolaDogAge(10);
calcolaDogAge(9);
calcolaDogAge(12);
function calcolaHumanAge(etàumanacane){
    let etàcaneumana=etàumanacane/7
    console.log("Your dog is " +etàcaneumana+" years old in human years!");

}
calcolaHumanAge(14);
calcolaHumanAge(22);
calcolaHumanAge(21);
calcolaHumanAge(19);




 