/**
 * @file: The calculator.js
 * @author: Bioletto Marco
 * function that give the square of a given number
 * function that give the half of a given number
 * function that calculator
 */
 function squareNumber(numero) {
    let Risultato = Math.pow(numero,2);
    console.log('The result of squaring the number  '+ numero +'  is '+Risultato);
    return Risultato;
}
function halfNumber(numero) {
    divisione = numero/2;
    console.log('Half of '+numero+' is '+ divisione);
    return divisione;
}
function percentOf(num1,num2) {
    let calcola= (num1/num2)*100
    console.log(num1+' is '+ calcola+'% of '+num2);
    return calcola; 
}
function areaOfCircle(raggioCerchio) {
    let area = Math.PI * (Math.pow(raggioCerchio,2));
    console.log('The area for a circle with radius '+ raggioCerchio+ ' is '+ area.toFixed(2));
    return area;
}
function calculator(numero) {
    let divisione = halfNumber(numero);
    let Risultato= squareNumber(divisione);
    let area= areaOfCircle(Risultato,area);
    let calcola= percentOf(area);
}
console.log(squareNumber(2));
console.log(halfNumber(2));
console.log(percentOf(2));
console.log(areaOfCircle(2));
console.log(calculator(2));

