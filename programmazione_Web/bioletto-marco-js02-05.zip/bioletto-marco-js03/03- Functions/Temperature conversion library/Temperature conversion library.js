/**
 * @file: Temperature conversion library.js
 * @author: Bioletto Marco
 *function that trasform the temperature from Celsius to Fahrenheit
* function that trasform the temperature from Fahrenheit to Celsius
*/
 function celsiusToFahrenheit(Celsius) {
    let Fahrenheit= (Celsius * 9/5) + 32;
   return Fahrenheit;
}
function fahrenheitToCelsius(Fahrenheit) {
    let Celsius= (Fahrenheit-32)*5/9;
    return Celsius;
}
let Celsius=Math.random()*100;
console.log(Celsius.toFixed(0)+" Celsius is "+celsiusToFahrenheit(Celsius).toFixed(0)+" Fahrenheit");
let Fahrenheit=Math.random()*100;
console.log(Fahrenheit.toFixed(0)+" Fahrenheit is "+fahrenheitToCelsius(Fahrenheit).toFixed(0)+" Celsius");