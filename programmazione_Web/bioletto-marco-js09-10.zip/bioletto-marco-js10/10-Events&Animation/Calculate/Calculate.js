/**
 * @file:Calculate.js
 * @author: Bioletto Marco
 * A demonstration of Events & Animation
 * 
 * Add inputs for half number, percentage and circle area
* Use the functions from the previous calculator exercises
* For each operation, create an event listener for the button, and when it's
  clicked, find the value of the appropriate input and show the result of the
  calculation in the solution div
*Afterwards, change the code so that you respond to key presses so that the
user doesn't have to click the button
*/
let halfButton = document.getElementById("half-button");
let halfInput = document.getElementById("half-input");
let halfSolution = document.getElementById("half-solution");

let percentButton = document.getElementById("percent-button");
let percent1Input = document.getElementById("percent1-input");
let percent2Input = document.getElementById("percent2-input");
let percentSolution = document.getElementById("percent-solution");

let areaButton = document.getElementById("area-button");
let areaInput = document.getElementById("area-input");
let areaSolution = document.getElementById("area-solution");

function halfNumber(num) {
  return num / 2;
}

function percentOf(num1, num2) {
  return (num1 / num2) * 100;
}

function areaOfCircle(radius) {
  return Math.PI * radius * radius;
}
halfButton.addEventListener("click", function() {
  let value = halfInput.value;
  let result = halfNumber(value);
  halfSolution.textContent = "Half of " + value + " is " + result;
});

percentButton.addEventListener("click", function() {
  let value1 = percent1Input.value;
  let value2 = percent2Input.value;
  let result = percentOf(value1, value2);
  percentSolution.textContent = value1 + " is " + result + "% of " + value2;
});

areaButton.addEventListener("click", function() {
  let value = areaInput.value;
  let result = areaOfCircle(value);
  areaSolution.textContent = "The area of a circle with radius " + value + " is " + result;
});
halfInput.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) { // Enter key
    event.preventDefault();
    halfButton.click();
  }
});

percent1Input.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) { // Enter key
    event.preventDefault();
    percentButton.click();
  }
});

percent2Input.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) { // Enter key
    event.preventDefault();
    percentButton.click();
  }
});

areaInput.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) { // Enter key
    event.preventDefault();
    areaButton.click();
  }
});