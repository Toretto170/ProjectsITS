/**
 * @file: Story.js
 * @author: Bioletto Marco
 * 
 * A demonstration of Events & Animation
 * Add an event listener to the button so that it calls a makeStory function
  when clicked.
*In the makeStory function, retrieve the current values of the form input
  elements, make a story from them, and output that in the story div (like"Joseph really likes pink cucumbers.")
 */

const storyBtn = document.getElementById("story-btn");
const storyDiv = document.getElementById("story");

storyBtn.addEventListener("click", makeStory);

function makeStory() {
  const name = document.getElementById("name").value;
  const food = document.getElementById("food").value;
  const color = document.getElementById("color").value;
  
  const story = `${name} really likes ${color} ${food}.`;
  
  storyDiv.innerText = story;
}

