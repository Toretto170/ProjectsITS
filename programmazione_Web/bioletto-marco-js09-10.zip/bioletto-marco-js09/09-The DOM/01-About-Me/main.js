/**
 * @file: About-Me
 * @author: Bioletto Marco
 * Exercise the DOM
 */

/**
 * Add an external javascript file called main.js
* In JavaScript:
* Change the body style so it has a font-family of "Arial, sans-serif"
* Replace each of the spans (nickname, favorites, hometown) with your own information
* Iterate through each li and change the class to "list-item"
* Create a new img element and set its src attribute to a picture of you
* Append that element to the page
* Add an external css file using Javascript
* The external css file should make items with the .list-item class white, bold and with an
    orange background
* The external css file should be applied after 4 seconds
 */

let body = document.body;
let head = document.head;

body.style.fontFamily = 'Arial, sans-serif';


window.onload = function() {
    var nicknameSpan = document.getElementById("nickname");
    nicknameSpan.textContent = "Bioletto";
    
    var favoritesSpan = document.getElementById("favorites");
    favoritesSpan.textContent = "Tennis and football";
    
    var hometownSpan = document.getElementById("hometown");
    hometownSpan.textContent = "Torino";

    let liClass = document.querySelectorAll("li");
    let liClassArray = Array.from(liClass);
    
    for(var i=0;i<liClassArray.length;i++) {
        liClassArray[i].className = "list-item";
    }; 
    
    let link = document.createElement("link");
    link.rel = "stylesheet";
    link.type = "text/css";
    link.href = "main.css"; 
    
    setTimeout(() => {
        document.head.appendChild(link)
    }, 4000);
    
};



let newImg = document.createElement("img");
newImg.src = "FotoBiolettoM.jpg";
body.appendChild(newImg);






