/**
 * @file: The-Book-List
 * @author: Bioletto Marco
 * Exercise the DOM
 */

/**
*Create a complete webpage with a title, description and all other HTML tags
In the body add an h1 title of "My Book List"
In javascript, iterate through the array of books.
For each book, create HTML element with the book title and author and append it to the page
Use a ul and li to display the books
Add a url property to each book object that contains the cover image of the book
Add the image to the HTML using Javascript
Using javascript change the style of the book depending on whether you have read it or not
Add an external css file that applies after 5 seconds
Now change the style of the book depending on whether you have read it or not using both 
css and javascript (the CSS should use a different color for read books)
*/

let books = [
    {
        title: 'The Catcher in the Rye',
        author: 'Don Norman',
        alreadyRead: false
    }, 
    {
        title: 'Wuthering Heights',
        author: 'J. D. Salinger',
        alreadyRead: true
    },
    {
        title: 'To Kill a Mockingbird',
        author: 'Harper Lee',
        alreadyRead: false
    }, 
    {
        title: '1984',
        author: 'George Orwell',
        alreadyRead: true
    }
];


let immagini = [
    {
        coll : "https://m.media-amazon.com/images/I/61fgOuZfBGL.jpg"    
    },
    {
        coll : "https://pictures.abebooks.com/isbn/9788193387634-it.jpg"
    },
    {
        coll : "https://m.media-amazon.com/images/I/51WJvKeUz7L.jpg"
    },
    {
        coll : "https://m.media-amazon.com/images/I/81StSOpmkjL.jpg"
    }
]


let body = document.body;

let list = document.createElement("ul");
body.appendChild(list);

for(var i=0;i<books.length;i++) {
    let puntoLi = document.createElement("li");
    list.appendChild(puntoLi);
    
    let anchor = document.createElement("a");
    puntoLi.appendChild(anchor);
    anchor.href = immagini[i].coll;
    anchor.textContent = books[i].title + ", by " + books[i].author;

    if(books[i].alreadyRead==false) {
        anchor.style.fontFamily = "Arial";
    } else {
        anchor.style.fontFamily = "Calabri";
    }

    if(books[i].alreadyRead==true) {
        anchor.className = "read"
    }

    let link = document.createElement("link");
    link.rel = "stylesheet";
    link.type = "text/css";
    link.href = "main.css"; 
    setTimeout(() => {
        document.head.appendChild(link)
    }, 5000);  
}




   