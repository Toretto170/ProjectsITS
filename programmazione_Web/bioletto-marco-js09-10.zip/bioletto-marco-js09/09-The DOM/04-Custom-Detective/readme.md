/**
 * @file:04-Custom-Detective
 * @author: Bioletto Marco
 */
/*name sites:https://www.juventus.com/it*/


document.getElementsByClassName("d3-o-site-logo");

document.getElementsByClassName(" d3-o-media-object__picture");

document.getElementById("main-content");

document.getElementById("onetrust-consent-sdk");

document.getElementsByTagName("a");

document.getElementsByTagName("script");

document.getElementsByTagName("img");

document.getElementsByClassName("jcom-c-hero jcom-c-hero-showcase jcom-c-hero-showcase--mp4 d3-l-section-row");

document.getElementsByTagName("div");

document.getElementsByTagName("h2");