/**
 * @file:03-DOM-Detective
 * @author:Bioletto Marco
 */

/*to select every image on the page*/
document.getElementsByTagName("picture");

/*to select the main menu at the top of the page*/
document.getElementsByClassName("menu-item menu-lite js-menu-lite");

/*to select the news items under "News"*/
document.getElementsByClassName("carousel news__carousel scrollbar-17 is-ready");

/*to select the footer*/
document.getElementsByTagName("footer");

/*to select all the social media links at the bottom of the page*/
document.getElementsByClassName("footer-microservice-socials");