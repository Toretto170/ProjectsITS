/*
 * @file: The-would-guesser.js
 * @author: Bioletto Marco
 * A demonstration of Arrays
 * 
 * This exercise asks you to build two arrays
 * One array for the letters instead another for the guessed letters
 * Have maximum retries and check if letter is in array
 */
    let lettereAlfa=["A","B","C","D","E"];
    let parole=["Aquile","Batuffolo","Coniglio","Delfino","Elefante"];
    letNumTentativi=6;
    letRimanenti=maxRimanenti
 function guessLetter(lettere){
    for(i=0;i<lettereAlfa.length;i++){
        if(lettereAlfa[i]===lettere){
         Indovina[i]=lettere;
        Corrente=true;
        if(lettereAlfa!=lettere){
            return false;
         }
         guessLetter("A");
         guessLetter("B");
         guessLetter("C");
         guessLetter("D");
         guessLetter("E");



    }
        
    }
 }

