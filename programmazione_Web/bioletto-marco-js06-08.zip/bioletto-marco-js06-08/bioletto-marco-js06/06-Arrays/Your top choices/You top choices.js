/*
 * @file: you-top-choices.js
 * @author: Bioletto Marco
 * A demonstration of Arrays
 * This exercise asks you to write an array and inside it must contain your favorite choices
 * For each choice put the choice number next to it
 * Finally, print a string on the screen
 */
    let sceltaPref=["Cane","Gatto",888,"Mercedes"];
    for (let i = 0; i < sceltaPref.length; i++) {
        let Suffx;
        switch (i + 1) {
        case 1:
       Suffx = "1st";
        break;
        case 2:
        Suffx = "2nd";
        break;
        case 3:
        Suffx = "3rd";
        break;
        case 4:
            Suffx="4th";
            break;
        console.log("My #1 choice is "[Suffx+1]);
    }
}