/**
 * @file: The-Cash-Register.js
 * @author: Bioletto Marco
 *A demonstration of object
 *Function that registers credit card 
 *This exercise asked to call the cashRegister function
*Register your credit card 
*/
function cashRegister(carta){
    let elemento= Object.keys(carta);
   let somma = 0; 
    
    for (let i = 0; i < elemento.length; i++) {
      let NomeElemento = elemento[i]; 
      let ElementoPrincipale = carta[NomeElemento]; 
      somma += Number.parseFloat(ElementoPrincipale); 
    }
  
    return somma;
  }