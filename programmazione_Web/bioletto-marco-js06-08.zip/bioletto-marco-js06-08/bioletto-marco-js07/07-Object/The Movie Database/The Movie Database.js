/**
 * @file: The-Movie-Database.js
 * @author: Bioletto Marco
 *A demonstration of object
 *Function that plays with the names of favorite movies
 *
*/
let myFavMovie = {
    Titolo: "Pirates of the Caribbean of Caraibe",
    Durata: 160,
    Stelle: ["Pirates of the Caribbean of Caraibe"]
};

function printMovie(Film) {
    console.log(Film.Titolo + ' lasts for ' + Film.Durata + ' minutes');
    let StelleString = "Stelle:";
    for (let i = 0; i < Film.Stelle.length; i++) {
        StelleString += Film.Stelle[i];
        if (i != Film.Stelles.length -1) {
            StelleString += ', ';
        }
    }
    console.log(sStelleString);
}


function printMovie(movie) {
    console.log(movie.title + ' lasts for ' + movie.duration + ' minutes');
    console.log('It stars ' + movie.stars.join(', '));
}
printMovie(myFavMovie);
