/**
 * @file: The-Credit-Card-Validation.js
 * @author: Bioletto Marco
 *A demonstration of object
 *Function that calculates credit card numbers
 *If the number is entered correctly the validation is successful otherwise the validation is failed
*/
function validateCreditCard(NumeroCartaCredito){

    if(NumeroCartaCredito.length !== 16){
      return false;
    }
    for(let i = 0; i < NumeroCartaCredito.length; i++){
     let NumeroCorrente = NumeroCartaCredito[i];
  
      NumeroCorrente = Number.parseInt(NumeroCorrente);

      if(!Number.isInteger(NumeroCorrente)){
        return false;
      }
    }
  
   let oggetto = {};
    for(let i = 0; i < NumeroCartaCredito.length; i++){
      oggetto[NumeroCartaCredito[i]] = true;
    }
    if(Object.keys(oggetto).length < 2){
      return false;
    }

    if(NumeroCartaCredito[NumeroCartaCredito.length - 1] % 2 !== 0){
      return false;
    }

    let somma = 0;
    for(let i = 0; i <  NumeroCartaCredito.length; i++){
      somma += Number(NumeroCartaCredito[i]);
    }
    if(somma >= 16){
      return true;
    }
    else{
      return false;
    }
  };
  
  console.log(NumeroCartaCredito("9999777788880000")); 
  console.log(NumeroCartaCredito("6666666666661666"));
  console.log(NumeroCartaCreditod("abcbd92332119c011112")); 
