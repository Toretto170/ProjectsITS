/**
 * @file: The-Reading-List.js
 * @author: Bioletto Marco
 *A demonstration of object
 *Funzione che gioca con gli array, con i libri preferiti
 *Finally, print the books with the relevant words: You have read/You have not yet read the book
*/


let books = [
    {
      Titolo: "Friendship Trilogy",
      Autore: "Luis Sepúlveda",
      etto: true
    },
    {
      Titolo: "The Most Human Human",
      Autore: 'Brian Christian',
      Letto: false
    }
  ];
  
  for (let i = 0; i < books.length; i++) {
    let book = books[i];
    let bookInfo = book.Titolo + '" by ' + book.Autore;
    if (book.Letto) {
      console.log("You already read " + bookInfo);
    } 
    else
     {
      console.log("You haven't read yet " + bookInfo);
    }
  }
  