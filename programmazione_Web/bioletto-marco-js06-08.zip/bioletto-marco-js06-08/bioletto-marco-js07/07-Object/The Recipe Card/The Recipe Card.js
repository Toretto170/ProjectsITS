/**
 * @file: The-Recipe-Card.js
 * @author: Bioletto Marco
 *A demonstration of object
 *Function that asks you to make a recipe of your favorite cake
*Finally, print the title of the cake, the portions and the related ingredients
*/
let recipe = {
    Titolo: "Cake",
    Porzioni: 2,
    Ingredienti: ["Farina,Zucchero,Uova,Burro"]
};

console.log(recipe.Titolo);
console.log("Porzioni: " + recipe.servings);
console.log("Ingredienti :");
for (let i = 0; i < recipe.Ingredienti.length; i++) {
    console.log(recipe.Ingredienti[i]);
}