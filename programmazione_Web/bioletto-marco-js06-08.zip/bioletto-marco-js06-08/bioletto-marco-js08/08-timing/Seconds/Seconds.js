/**
 * @file: Seconds.js
 * @author: Bioletto Marco
 * Exercise on timing 
 * 
 * Write two functions that based on the current date and time output the number
 * of seconds:
 * getSecondsToday() returns the number of seconds from the beginning of
 * today.
 * getSecondsToTomorrow() returns the number of seconds till tomorrow.
 */

function getSecondsToday() {
    let now = new Date();
    let startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    let seconds = (now.getTime() - startOfDay.getTime()) / 1000;
    return seconds;
    }
    
    function getSecondsToTomorrow() {
    let now = new Date();
    let tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    let seconds = (tomorrow.getTime() - now.getTime()) / 1000;
    return seconds;
    }
    
    console.log('Seconds since start of day:', getSecondsToday());
    console.log('Seconds till tomorrow:', getSecondsToTomorrow());
    
    
    