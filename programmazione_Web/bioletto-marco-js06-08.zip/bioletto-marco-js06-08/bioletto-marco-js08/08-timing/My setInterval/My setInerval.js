/**
 * @file:DateAgo.js
 * @author: Bioletto Marco
 * Exercise on timing 
 * 
 * Create a function getDateAgo(date, days) that returns the day of the month
 * n days ago from the given date.
 * ● For instance, if today is the 20th, then getDateAgo(new Date(), 1) should be
 * 19th and getDateAgo(new Date(), 2) should be 18th.
 * ● The function should work reliably with any valid Date object. Test it.
 */
function mySetInterval(callback, delay) {
    let counter = 0;
    let intervalId;
    
    const runInterval = () => {
    intervalId = setTimeout(() => {
    counter++;
    callback();
    
      if (counter === 15) {
        clearInterval(intervalId);
        console.log("Interval stopped after 15 iterations");
      } else {
        runInterval();
      }
    }, 
    delay
    )
  }
    };