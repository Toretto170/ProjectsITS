function formatDate(date){
    let now=new DataTransfer();
    let timeDiff = (now.getTime() - date.getTime()) / 1000; 
    if (timeDiff < 1) {
return "right now";
} 
    else if (timeDiff < 60) {
    return Math.floor(timeDiff) + " sec. ago";
} 
    else if (timeDiff < 3600) {
    return Math.floor(timeDiff / 60) + " min. ago";
} 
    else {
    let day = addLeadingZero(date.getDate());
    let month = addLeadingZero(date.getMonth() + 1);
    let year = date.getFullYear().toString().substr(-2);
    let hours = addLeadingZero(date.getHours());
    let minutes = addLeadingZero(date.getMinutes());
    return {day},{month},{year},{hours},{minutes};
}
}

function addLeadingZero(value) {
return value < 10 ? "0" + value : value.toString();
}
