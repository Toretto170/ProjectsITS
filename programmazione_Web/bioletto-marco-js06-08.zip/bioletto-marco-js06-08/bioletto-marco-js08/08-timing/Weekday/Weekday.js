/**
 * @file: Weekday.js
 * @author: Bioletto Marco
 * Exercise on timing 
 * 
 * Write a function getWeekDay(date) to show the weekday in short format:
 * ‘MO’, ‘TU’, ‘WE’, ‘TH’, ‘FR’, ‘SA’, ‘SU’.
 *      ● Write another function that does the same in Italian.
 *      ● Add a language parameter to the function that accepts ‘en’ or ‘it’ and
 *        outputs the day in the correct language.
 */



// English weekday function
function getWeekDay(date) {
    const weekdays = ['SU', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA'];
    return weekdays[date.getDay()];
    }
    
    // Italian weekday function
    function getWeekDayIT(date) {
    const weekdays = ['DO', 'LU', 'MA', 'ME', 'GI', 'VE', 'SA'];
    return weekdays[date.getDay()];
    }
    
    // Function with language parameter
    function getWeekDayLang(date, lang) {
    if (lang === 'it') {
    return getWeekDayIT(date);
    } else {
    return getWeekDay(date);
    }
    }
    
    // Example usage
    const today = new Date();
    console.log('English:', getWeekDayLang(today, 'en')); // output: "TU"
    console.log('Italian:', getWeekDayLang(today, 'it')); // output: "MA"
    
    
    
    