import requests
import json
from requests_ntlm import HttpNtlmAuth

def updateItem():
    r=requests.get("http://127.0.0.1:7048/BC210/api/its/administration/v1.0/itemledgerentries", auth=HttpNtlmAuth('studenti.local\\ICTS22-24.183',''))
    r=r.json()
    r=r["value"]
    r=json.dumps(r)

    x=requests.post("http://127.0.0.1:8000/items", r)

def updateCapacity():
    r=requests.get("http://localhost:7048/BC210/api/its/administration/v1.0/capacityledgerentries", auth=HttpNtlmAuth('studenti.local\\ICTS22-24.183',''))
    r=r.json()
    r=r["value"]
    r=json.dumps(r)
   
    
    x=requests.post("http://127.0.0.1:8000/capacities", r)

def main():
    updateItem()
    updateCapacity()

main()