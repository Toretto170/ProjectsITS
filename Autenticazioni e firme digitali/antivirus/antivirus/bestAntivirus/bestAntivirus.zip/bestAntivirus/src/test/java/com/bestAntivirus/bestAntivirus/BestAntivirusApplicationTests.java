package com.bestAntivirus.bestAntivirus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BestAntivirusApplicationTests {

	@Test
	void contextLoads() {
	}

}
