package com.bestAntivirus.bestAntivirus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BestAntivirusApplication {

	public static void main(String[] args) {
		SpringApplication.run(BestAntivirusApplication.class, args);
	}

}
